/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package coefficient;

import java.util.Scanner;

/**
 *
 * @author emily
 */
public class Coefficient {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Coefficient a: ");
        int a = scanner.nextInt();
        System.out.println("Coefficient b: ");
        int b = scanner.nextInt();
        System.out.println("Coefficient c: ");
        int c = scanner.nextInt();
        
        double d = (Math.pow(b,2)-(4*a*c));
        
        if(d==0){
            System.out.println("Quadratic equation has 1 real solution");
        }if(d>0){
            System.out.println("Quadratic equation has 2 real solutions");
        }else{
            System.out.println("Quadratic equation has no real solutions");
        }
    }
    
}
