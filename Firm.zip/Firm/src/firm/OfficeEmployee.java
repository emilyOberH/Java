/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package firm;

/**
 *
 * @author emily
 */
public class OfficeEmployee extends Employee{
    static String department = "IT";

    public OfficeEmployee() {
    }

    
    public OfficeEmployee(String name, String position, int salary, double hireDate) {
        super(name, position, salary, hireDate);
    }
    
    public void officeEmployeeData(){
        super.employeeData();
        System.out.print(", department: "+ department);
    }
}
