/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package firm;

/**
 *
 * @author emily
 */
public class Boss extends Employee {
    int bonus;

    public Boss() {
    }

    public Boss(String name, String position, int salary, double hireDate) {
        super(name, position, salary, hireDate);
    }

    public Boss(int bonus) {
        this.bonus = bonus;
    }

    public Boss(int bonus, String name, String position, int salary, double hireDate) {
        super(name, position, salary, hireDate);
        this.bonus = bonus;
    }
    
    public void bossData(){
        super.employeeData();
        System.out.print(", bonus: "+ bonus);
    }
}
