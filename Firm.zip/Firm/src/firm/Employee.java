/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package firm;

/**
 *
 * @author emily
 */
public class Employee {
    String name;
    String position;
    int salary;
    double hireDate;

    public Employee() {
    }

    public Employee(String name, String position, int salary, double hireDate) {
        this.name = name;
        this.position = position;
        this.salary = salary;
        this.hireDate = hireDate;
    }
    
    public void employeeData(){
        System.out.println("Employee name: "+name+", position: "+position+", salary: "+salary+", hireDate: "+ hireDate);
    }
}
