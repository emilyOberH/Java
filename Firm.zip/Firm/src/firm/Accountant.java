/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package firm;

/**
 *
 * @author emily
 */
public class Accountant extends OfficeEmployee{
    String softwareUsed;
    
    public Accountant(String softwareUsed) {
        this.softwareUsed = softwareUsed;
    }

    public Accountant(String softwareUsed, String name, String position, int salary, double hireDate) {
        super(name, position, salary, hireDate);
        this.softwareUsed = softwareUsed;
    }

    public Accountant() {
    }


    public void accountantData(){
        super.officeEmployeeData();
        System.out.print(", software used: "+ softwareUsed);
    }
    
    
}
