/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package firm;

/**
 *
 * @author emily
 */
public class Firm {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Employee e1 = new Employee("Bob", "clerk", 4500, 27.03);
        e1.employeeData();
        
        Boss b1 = new Boss(2000, "John", "CEO", 10000, 1.01);
        b1.bossData();
        
        OfficeEmployee o1 = new OfficeEmployee("Sam", "secretary", 4000, 7.07);
        o1.officeEmployeeData();
        
        Accountant a1 = new Accountant("basic", "Amy", "accountant", 1700, 9.08);
        a1.accountantData();
    }
    
}
