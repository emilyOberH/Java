/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package animals;

/**
 *
 * @author emily
 */
public class Animals {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Dog d1 = new Dog();
        d1.speak();
        d1.eat();
    
        Puppy p1 = new Puppy();
        p1.speak();
        p1.eat();
        
        Cat c1 = new Cat();
        c1.speak();
        c1.eat();
        
        Tiger t1 = new Tiger();
        t1.speak();
        t1.eat();
        
        Puma pu1 = new Puma();
        pu1.speak();
        pu1.eat();
        
        Mouse m1 = new Mouse();
        m1.speak();
        m1.eat();
        
        Animal a1 = new Animal();
        a1.speak();
        a1.eat();
    }
        
}
