/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animals;

/**
 *
 * @author emily
 */
public class Animal {
    static String voice = "...";
    static String food = "omnivore";

    public Animal() {
    }
    
    
    public void speak(){
        System.out.println("Voice: "+voice);
    }
    
    public void eat(){
        System.out.println("Food: "+food);
    }
}
