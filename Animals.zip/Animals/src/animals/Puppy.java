/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animals;

/**
 *
 * @author emily
 */
public class Puppy extends Dog{
    static String voice = "wuf wuf wuf";
    static String food = "carnivore";

    public Puppy() {
    }
    
    @Override
    public void speak(){
        System.out.println("Voice: "+voice);
    }
    
    @Override
    public void eat(){
        System.out.println("Food: "+food);
    }
}
