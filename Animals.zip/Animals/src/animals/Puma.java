/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animals;

/**
 *
 * @author emily
 */
public class Puma extends Cat{
    static String voice = "grr";
    static String food = "carnivore";

    public Puma() {
    }
    
    @Override
    public void speak(){
        System.out.println("Voice: "+voice);
    }
    
    @Override
    public void eat(){
        System.out.println("Food: "+food);
    }
}
