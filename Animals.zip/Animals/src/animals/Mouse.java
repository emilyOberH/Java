/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package animals;

/**
 *
 * @author emily
 */
public class Mouse extends Animal{
    static String voice = "squeak";
    static String food = "herbivore";

    public Mouse() {
    }
    
    @Override
    public void speak(){
        System.out.println("Voice: "+voice);
    }
    
    @Override
    public void eat(){
        System.out.println("Food: "+food);
    }
}
