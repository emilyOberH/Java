/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package exep;

import java.util.Scanner;

/**
 *
 * @author emily
 */
public class Exep {
    
    public static void main(String[] args) {
        int a = 1, b = 1;
        Scanner input = new Scanner(System.in);
        System.out.println("Enter a:");
        try{
            a=input.nextInt();
        }catch(java.util.InputMismatchException ev){
            System.out.println("Wrong data");
            System.exit(0);
        }
        System.out.println("Enter b:");
        try{
            b=input.nextInt();
        }catch(java.util.InputMismatchException ev){
            System.out.println("Wrong data");
            System.exit(0);
        }
        
        /*System.out.println("Enter b:");
        b=input.nextInt();*/
        try{
            System.out.println("a/b="+ (a/b));
        }catch(java.lang.ArithmeticException ev){
            System.out.println("Do not divide by 0");
        }
        System.out.println("Rest of the program.");
    }
    
}
