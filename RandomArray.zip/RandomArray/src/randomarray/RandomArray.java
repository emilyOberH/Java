/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package randomarray;

import java.util.Random;

/**
 *
 * @author emily
 */
public class RandomArray {

    public static void main(String[] args) {
        Random rand = new Random();
        
        int [] arr = {0,0,0,0,0};
        
        for(int i=0; i<5; ++i){
            arr[i] = rand.nextInt(100);
        }
        
        for(int i=0; i<5; ++i){
            System.out.println(arr[i]);
        }
        
    }
    
}
