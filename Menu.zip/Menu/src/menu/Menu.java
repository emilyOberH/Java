/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package menu;

import java.util.Scanner;

/**
 *
 * @author emily
 */
public class Menu {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        
        for (int i=1; i<5; ++i){
            if(i==4){
               System.out.println(i+". The end"); 
            }else{
               System.out.println(i+". Option "+i); 
            }
            
        }
        
        int n = 0;
        while(n<1||n>3){
           n=sc.nextInt(); 
        }
        System.out.println("You have chosen Option "+n);
    }
    
}
