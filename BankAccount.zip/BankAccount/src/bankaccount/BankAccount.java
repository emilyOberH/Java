/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package bankaccount;

/**
 *
 * @author emily
 */
public class BankAccount {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Account p1 = new Account("Steve", "B.");
        p1.transaction(200);
        p1.transaction(100);
        p1.setLimit(-50.24);
        
        p1.transaction(-100);
        p1.transaction(-2000);
    }
    
}
