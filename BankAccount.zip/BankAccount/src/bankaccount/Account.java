package bankaccount;

/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author emily
 */
public class Account {
    String name;
    String surname;
    double amount = 0.0;
    double limit = 0.0;

    public Account() {
    }

    public Account(String name, String surname) {
        this.name = name;
        this.surname = surname;
    }
    
    public void transaction(double howMuch){
        
        if(amount + howMuch>=limit){
            amount = amount + howMuch;
            System.out.println("Balance: "+amount); 
        }else{
            System.out.println("Limit for withdrawals is: "+limit+". Your current balance is: "+amount+". Cannot withdraw more.");
        }
        
    }
    
    public void setLimit(double l){
        limit = l;
    }
    
    
    
}
