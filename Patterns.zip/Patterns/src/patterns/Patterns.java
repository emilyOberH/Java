/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package patterns;

/**
 *
 * @author emily
 */
public class Patterns {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
    Pattern p1 = new Pattern();
    Pattern p2 = new Pattern('o','$',5);
    System.out.println(p1.giveDescription());
    p1.print();
    System.out.println(p2.giveDescription());
    p2.print();
    p1.changeData('-','+',7);
    p1.print();

    }
    
}
