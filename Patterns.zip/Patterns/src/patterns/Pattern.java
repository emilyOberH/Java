/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package patterns;

/**
 *
 * @author emily
 */
public class Pattern {
    char ch1 = '?', ch2 ='?';
    int n = 1;
    
    
    public Pattern() {
    }

    public Pattern(char ch1, char ch2, int n) {
        this.ch1 = ch1;
        this.ch2 = ch2;
        this.n = n;
    }
    
    public String giveDescription(){
        return "Pattern: "+n+" x ("+ch1+","+ch2+").";
    }
    public void print(){
        for(int i=0; i<n; ++i){
            System.out.print(ch1+" "+ch2);
        }
        System.out.println("");
    }
    
    public void changeData(char c1, char c2, int num){
        ch1 = c1;
        ch2 = c2;
        n = num;
    }
}
