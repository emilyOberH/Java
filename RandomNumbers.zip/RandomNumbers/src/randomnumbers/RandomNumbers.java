/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package randomnumbers;

import java.util.Random;
import java.util.Scanner;

/**
 *
 * @author emily
 */
public class RandomNumbers {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Random rand = new Random();
        
        Scanner sc = new Scanner(System.in);
        System.out.println("From 0 to:");
        int n = sc.nextInt();
        
        int radRand = 1;
        
        while (radRand!=0){
            for(int i=0; i<10; i++){
                radRand = rand.nextInt(n);
                System.out.println(""+radRand);
            }   
        }

    }
    
}
