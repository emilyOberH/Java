/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package rectangle_with_java;


public class Rectangle {
    float width, height;

    public Rectangle() {
    }

    public Rectangle(float width, float height) {
        this.width = width;
        this.height = height;
    }
    
    
    void area(){
        System.out.println("Area of rectangle is: "+width*height);
    }
    void perimeter(){
        System.out.println("Perimeter of rectangle is: "+(2*width+2*height));
    }
}
