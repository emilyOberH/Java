/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package rectangle_with_java;

/**
 *
 * @author emily
 */
public class Rectangle_with_Java {

    public static void main(String[] args) {
        Rectangle rec1 = new Rectangle(2.3f, 4.33f);
        rec1.area();
        rec1.perimeter();
        
        new Rectangle(5.5f, 8.88f).area();
        new Rectangle(5.5f, 8.88f).perimeter();
    }
    
}
